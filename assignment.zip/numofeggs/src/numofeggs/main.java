package numofeggs;

public class main {
	public static void main(String[] args) {
	NumOfEggs numofeggs=new NumOfEggs(763);
    System.out.println(numofeggs.getGross()+"gross");
    System.out.println(numofeggs.getDozen()+"dozen");
    System.out.println(numofeggs.getRemaining()+"remaining");
	}   
}
