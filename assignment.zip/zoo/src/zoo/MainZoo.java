package zoo;

public class MainZoo{

		public static void main(String[] args) {
			DelhiZoo dZ = new DelhiZoo();
			dZ.display();
		}

}
