package area_and_parameter;

public class main {
	public static void main(String[] args) {
		AreaAndPerimeter AnP=new AreaAndPerimeter();

		AnP.areaandperimeter(7,5);
		AnP.areaandperimeter(6.5);
		AnP.areaandperimeter(8);
		
	}

}
